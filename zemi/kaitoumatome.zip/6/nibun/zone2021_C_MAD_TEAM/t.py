t = 0
print(t)
for i in range(5):
  t += 1 << i
